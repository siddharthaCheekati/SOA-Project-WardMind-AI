PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT,
  legacy_password TEXT, role TEXT NOT NULL CHECK(role IN ('Admin','Doctor','Nurse','Ward Staff')),
  department TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctors (
  id TEXT PRIMARY KEY, user_id TEXT UNIQUE REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL, department TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS nurses (
  id TEXT PRIMARY KEY, user_id TEXT UNIQUE REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL, department TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS wards (
  id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, code TEXT NOT NULL UNIQUE,
  capacity INTEGER NOT NULL CHECK(capacity > 0), lead_doctor_id TEXT REFERENCES doctors(id)
);
CREATE TABLE IF NOT EXISTS beds (
  id TEXT PRIMARY KEY, ward_id TEXT NOT NULL REFERENCES wards(id) ON DELETE CASCADE,
  label TEXT NOT NULL UNIQUE, status TEXT NOT NULL CHECK(status IN ('available','occupied','reserved','maintenance'))
);
CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, age INTEGER NOT NULL CHECK(age BETWEEN 0 AND 130),
  gender TEXT NOT NULL, condition TEXT NOT NULL, clinical_status TEXT NOT NULL CHECK(clinical_status IN ('stable','watch','critical')),
  heart_rate INTEGER NOT NULL, spo2 INTEGER NOT NULL CHECK(spo2 BETWEEN 0 AND 100),
  temperature REAL NOT NULL, assigned_doctor_id TEXT REFERENCES doctors(id)
);
CREATE TABLE IF NOT EXISTS admissions (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  ward_id TEXT NOT NULL REFERENCES wards(id), bed_id TEXT NOT NULL REFERENCES beds(id),
  admitted_at TEXT NOT NULL, discharged_at TEXT, admitted_by_user_id TEXT REFERENCES users(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_admission_per_patient ON admissions(patient_id) WHERE discharged_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS one_active_admission_per_bed ON admissions(bed_id) WHERE discharged_at IS NULL;
CREATE TABLE IF NOT EXISTS alerts (
  id TEXT PRIMARY KEY, patient_id TEXT REFERENCES patients(id) ON DELETE SET NULL,
  kind TEXT NOT NULL, severity TEXT NOT NULL CHECK(severity IN ('critical','warning','info')),
  title TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ai_assessments (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  risk_level TEXT NOT NULL CHECK(risk_level IN ('Low','Moderate','High')),
  reasons TEXT NOT NULL, recommendation TEXT NOT NULL, assessed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY, text TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS hospital_settings (
  id INTEGER PRIMARY KEY CHECK(id = 1), hospital_name TEXT NOT NULL, hospital_code TEXT NOT NULL,
  alerts_enabled INTEGER NOT NULL DEFAULT 1, auto_refresh INTEGER NOT NULL DEFAULT 1
);
