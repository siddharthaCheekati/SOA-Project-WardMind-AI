PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS alarm_events (
  alert_id TEXT PRIMARY KEY REFERENCES alerts(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','acknowledged','resolved')),
  acknowledged_by TEXT, acknowledged_at TEXT, resolved_at TEXT,
  escalation_level INTEGER NOT NULL DEFAULT 0, escalated_to TEXT,
  escalation_due_at TEXT
);
CREATE TABLE IF NOT EXISTS vital_sign_history (
  id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  heart_rate INTEGER NOT NULL, spo2 INTEGER NOT NULL, temperature REAL NOT NULL,
  recorded_at TEXT NOT NULL
);
