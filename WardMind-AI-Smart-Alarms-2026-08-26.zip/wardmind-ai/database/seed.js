const {initialize,readStore,file}=require('./database');
initialize();
const store=readStore();
console.log(`WardMind SQLite database ready: ${file}`);
console.log(`Seeded ${store.users.length} users, ${store.patients.length} patients, and ${store.wards.length} wards.`);
