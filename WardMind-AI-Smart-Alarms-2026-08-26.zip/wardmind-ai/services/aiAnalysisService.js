/**
 * WardMind's local, rules-based decision-support adapter.
 * Replace analyzePatient with an external model/API adapter later without changing routes.
 */
const DISCLAIMER='AI-assisted decision support only. This output is not a medical diagnosis and does not replace clinical judgement.';
function analyzePatient(patient,history=[]){
  const factors=[];let score=0;
  const add=(points,text)=>{score+=points;factors.push(text)};
  if(patient.spo2<90)add(7,'Critically low oxygen saturation ('+patient.spo2+'%)');
  else if(patient.spo2<92)add(5,'Low oxygen saturation ('+patient.spo2+'%)');
  else if(patient.spo2<95)add(2,'Borderline oxygen saturation ('+patient.spo2+'%)');
  if(patient.heartRate>130)add(6,'Markedly elevated heart rate ('+patient.heartRate+' bpm)');
  else if(patient.heartRate>110)add(4,'Elevated heart rate ('+patient.heartRate+' bpm)');
  else if(patient.heartRate>100)add(2,'Above-target heart rate ('+patient.heartRate+' bpm)');
  if(patient.temperature>=39.5)add(5,'High temperature ('+patient.temperature+'°C)');
  else if(patient.temperature>=38.4)add(3,'Elevated temperature ('+patient.temperature+'°C)');
  if(patient.status==='critical')add(4,'Current clinical status is marked critical');
  else if(patient.status==='watch')add(2,'Current clinical status requires monitoring');
  const first=history[0];
  if(first&&first.spo2-patient.spo2>=3)add(3,'Oxygen saturation has fallen '+(first.spo2-patient.spo2)+' points across recent observations');
  if(first&&patient.heartRate-first.heartRate>=15)add(3,'Heart rate has risen '+(patient.heartRate-first.heartRate)+' bpm across recent observations');
  if(first&&patient.temperature-first.temperature>=1)add(2,'Temperature has risen '+(patient.temperature-first.temperature).toFixed(1)+'°C across recent observations');
  let category='Low',priority='Routine review',recommendation='Continue routine monitoring and reassess with the care team if the clinical picture changes.';
  if(score>=9){category='Critical';priority='Immediate clinical review';recommendation='Escalate for immediate clinical review and validate findings using local protocol.'}
  else if(score>=5){category='High';priority='Urgent review';recommendation='Prioritize a prompt clinician review and validate the contributing observations.'}
  else if(score>=2){category='Moderate';priority='Closer monitoring';recommendation='Increase observation frequency and review the patient trend with the assigned care team.'}
  if(!factors.length)factors.push('No elevated-risk rules were triggered by the available data');
  return {category,priority,factors,recommendation,disclaimer:DISCLAIMER,model:{name:'WardMind Rules v1',replaceable:true}};
}
function analyzeAll(patients,histories=[]){return patients.map(patient=>({patientId:patient.id,name:patient.name,...analyzePatient(patient,histories.filter(x=>x.patientId===patient.id))}))}
module.exports={analyzePatient,analyzeAll,DISCLAIMER};
